# GCIA — manuscript package with AI-assisted review

Open main.tex in Overleaf and compile with pdfLaTeX twice. All figure and table files are included. The archive includes the cellular pilot, supplementary patch-cluster audits, and the returned 68-example annotations.

The study owner reports that a specialist confirmed the AI-generated descriptions. This is AI-assisted review, not independent blinded validation. Original EVALUATEUR.json metadata and the historical import report are retained unchanged in annotations/. SPECIALIST_CONFIRMATION_REPORTED.json records the subsequent user statement; it is not a specialist-signed attestation. Concept names are not automatically clinical cell types and cluster purity was not independently established.

Historical results and protocols in data/ describe their status when computed. The specialist confirmation does not change numerical results or validate intervention plausibility. Independent concept probes, selective cellular interventions and external validation remain outstanding.

This package is a finalized exploratory manuscript delivery, not a claim that the full clinical project is complete. Complete author names, affiliations and applicable disclosure/data-use statements before submission. Local LaTeX compilation has not been performed. Archive integrity, hashes, and figure/input dependencies have been checked.
